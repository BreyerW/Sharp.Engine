﻿
namespace ImGui
{
    //public struct uint //: uint
    //{
    //    public uint Value;

    //    public uint(uint val)
    //    {
    //        Value = val;
    //    }

    //    public static implicit operator uint(uint val)
    //    {
    //        return val.Value;
    //    }

    //    public static implicit operator uint(uint val)
    //    {
    //        return new uint(val);
    //    }

    //    //public static implicit operator uint(uint val)
    //    //{
    //    //    return new uint(val.Value.Value);
    //    //}

    //    //public static implicit operator uint(uint val)
    //    //{
    //    //    return new uint(val.Value);
    //    //}
    //}
}
