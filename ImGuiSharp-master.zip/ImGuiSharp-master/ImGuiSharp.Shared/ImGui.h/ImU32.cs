﻿namespace ImGui
{
    //public struct uint
    //{
    //    public uint Value;

    //    public uint(uint val)
    //    {
    //        Value = val;
    //    }

    //    public static implicit operator uint(uint val)
    //    {
    //        return val.Value;
    //    }

    //    public static implicit operator uint(uint val)
    //    {
    //        return new uint(val);
    //    }
    //}
}
