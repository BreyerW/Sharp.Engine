﻿namespace ImGui
{
    //public struct ImWchar
    //{
    //    // character for keyboard input/display
    //}
}
