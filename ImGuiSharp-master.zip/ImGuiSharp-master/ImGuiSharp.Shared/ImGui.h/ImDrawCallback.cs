﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImGui
{
    public delegate void ImDrawCallback(ImDrawList parent_list, ImDrawCmd cmd);
}
