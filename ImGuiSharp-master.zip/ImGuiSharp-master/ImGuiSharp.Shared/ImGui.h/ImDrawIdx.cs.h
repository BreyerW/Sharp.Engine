﻿// Vertex index (override with, e.g. '#define ImDrawIdx unsigned int' in ImConfig)
#ifndef ImDrawIdx
typedef unsigned short ImDrawIdx;
#endif