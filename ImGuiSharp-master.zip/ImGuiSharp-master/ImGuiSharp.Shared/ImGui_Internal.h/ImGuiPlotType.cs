﻿
namespace ImGui
{
    internal enum ImGuiPlotType : int
    {
        ImGuiPlotType_Lines,
        ImGuiPlotType_Histogram
    }
}
