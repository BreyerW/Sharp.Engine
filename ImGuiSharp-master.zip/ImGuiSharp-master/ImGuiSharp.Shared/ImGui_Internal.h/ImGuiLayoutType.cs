﻿namespace ImGui
{
    // FIXME: this is in development, not exposed/functional as a generic feature yet.
    internal enum ImGuiLayoutType : int
    {
        ImGuiLayoutType_Vertical,
        ImGuiLayoutType_Horizontal
    }
}
