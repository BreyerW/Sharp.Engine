﻿// Data saved in imgui.ini file
struct ImGuiIniData
{
	char*       Name;
	uint     ID;
	ImVec2      Pos;
	ImVec2      Size;
	bool        Collapsed;
};