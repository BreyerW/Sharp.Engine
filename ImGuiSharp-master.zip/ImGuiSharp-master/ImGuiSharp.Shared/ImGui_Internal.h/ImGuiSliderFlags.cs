﻿namespace ImGui
{
using System;

    [Flags]
    internal enum ImGuiSliderFlags : int
    {
        ImGuiSliderFlags_Vertical = 1 << 0
    }
}
