﻿namespace ImGui
{
    internal enum ImGuiDataType : int
    {
        ImGuiDataType_Int,
        ImGuiDataType_Float
    }
}
